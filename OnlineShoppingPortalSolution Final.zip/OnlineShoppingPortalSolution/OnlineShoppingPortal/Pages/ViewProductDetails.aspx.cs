﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ShoppingCartDLL;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace OnlineShoppingPortal.Pages
{
    public partial class ViewProductDetails : System.Web.UI.Page
    {
       

        protected void Page_Load(object sender, EventArgs e)
        {
            //string cs= Request.QueryString["ProductId"];
            int sessiondetails= Convert.ToInt32((Session["ProductId"]));
            if (!Page.IsPostBack)
            {
               // string productDes = Request.QueryString["ProductBrand"];
                string connectionString = ConfigurationManager.ConnectionStrings["OnlineShoppingPortalDBConnectionString"].ConnectionString;
                DataTable dt = new DataTable();
                SqlConnection conn = new SqlConnection(connectionString);
                using (conn)
                {
                    SqlDataAdapter ad = new SqlDataAdapter("SELECT * FROM ProductTable Where productid="+sessiondetails, conn);
                    ad.Fill(dt);
                }
                DataList1.DataSource = dt;
                DataList1.DataBind();
            }

           // Session["Productinfo"] = Label1.Text;

        }

        protected void btnAddToCart_Click(object sender, EventArgs e)
        {
      //   string emailId=Session["EmailId"].ToString();

            string productId = Session["ProductId"].ToString();
            int productId1 = Convert.ToInt32(productId);

            try
            {

                CartDLLClass cartObj = new CartDLLClass();
                cartObj.AddToCart(Session["EmailId"].ToString(), productId1);

                Response.Redirect("ViewCartPage.aspx");
            }
            catch (NullReferenceException)
            {
                Response.Redirect("Login.aspx?ReturnUrl=ViewProductDetails.aspx");
            }
        }

        protected void btnBuyNow_Click(object sender, EventArgs e)
        {
            string productId = Session["ProductId"].ToString();
            int productId1 = Convert.ToInt32(productId);
            Session["OrderProductid"] = Session["ProductId"].ToString();
           
            try
            {
                if (Session["EmailId"].ToString() != " ")
                {
                    Response.Redirect("BuyCart.aspx");
                }
            }
            catch (NullReferenceException)
            {
               
                Response.Redirect("Login.aspx?ReturnUrl=BuyCart.aspx");
            }
           
              
             
          
        }


      /*  protected void Button1_Click(object sender, EventArgs e)
        {
            CartDLLClass cartObj = new CartDLLClass();
            cartObj.AddToCart("darshan.d@lntinfotech.com", Convert.ToInt32(Session["productId"]));

            Response.Redirect("ViewCartPage.aspx");
        }*/
    }
}