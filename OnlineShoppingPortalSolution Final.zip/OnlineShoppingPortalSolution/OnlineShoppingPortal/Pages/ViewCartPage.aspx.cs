﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OnlineShoppingPortal.Pages
{
    public partial class ViewCartPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!this.IsPostBack)
            {
               try
               {
                string connectionString = ConfigurationManager.ConnectionStrings["OnlineShoppingPortalDBConnectionString"].ConnectionString;
                string q = "Prc_ViewCart";
                SqlConnection con = new SqlConnection(connectionString);
                con.Open();
                SqlCommand cmd = new SqlCommand(q, con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@emailId", Session["EmailId"].ToString());
                SqlDataReader dr = cmd.ExecuteReader();
                GridView1.DataSource = dr;
                GridView1.DataBind();
                con.Close();
                  }
                catch(NullReferenceException)
                {
                    Response.Redirect("Login.aspx");
                }

            }  


        }
        protected void btnDelete_Click(object sender, EventArgs e)
        {
            
            Button btn = sender as Button;
            int cds = Convert.ToInt32(btn.CommandArgument);
            SqlConnection scon = new SqlConnection("Data Source=INFVA07182;Initial Catalog=OnlineShoppingPortalDB;Persist Security Info=True;User ID=sa;Password=Newuser123");
            string q = "Prc_DeleteItemCart";

            scon.Open();
            SqlCommand scmd = new SqlCommand(q, scon);
            scmd.CommandType = CommandType.StoredProcedure;
            scmd.Parameters.AddWithValue("@emailId", Session["EmailId"]);
            scmd.Parameters.AddWithValue("@productId", cds);
            scmd.ExecuteNonQuery();

            Response.Redirect("ViewCartPage.aspx");

        }

        protected void btnOrder_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            int cds = Convert.ToInt32(btn.CommandArgument);
            Session["ProductId123"]=cds;

            Response.Redirect("BuyCart.aspx");
        }

       
    }
}