﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OnlineShoppingPortal.Pages
{
    public partial class Home : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!Page.IsPostBack)
            {
                string connectionString = ConfigurationManager.ConnectionStrings["OnlineShoppingPortalDBConnectionString"].ConnectionString;
                DataTable dt = new DataTable();
                SqlConnection conn = new SqlConnection(connectionString);
                using (conn)
                {
                    SqlDataAdapter ad = new SqlDataAdapter("SELECT * FROM ProductTable", conn);
                    ad.Fill(dt);
                }
                DataList1.DataSource = dt;
                DataList1.DataBind();
            }
        }

        protected void btnView_Click1(object sender, EventArgs e)
        {

            Button btn = sender as Button;
            string cds = btn.CommandArgument.ToString();
            Session["ProductId"] = cds;
            Response.Redirect("ViewProductDetails.aspx");



        }
    }
}