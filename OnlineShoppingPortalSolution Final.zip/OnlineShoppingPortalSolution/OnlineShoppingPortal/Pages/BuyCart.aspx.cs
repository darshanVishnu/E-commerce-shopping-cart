﻿using ShoppingCartDLL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OnlineShoppingPortal.Pages
{
    public partial class BuyCart : System.Web.UI.Page
    {
        string orderId;
        string productBrand;
        string productRAM;
        string productProcessor;
        string productPrice;
        string emailId;
        int productId;
        string productImage;

        protected void Page_Load(object sender, EventArgs e)
        {
          try
          {
            productId = Convert.ToInt32(Session["ProductId"]);

            BuyProductClass buyProductObj = new BuyProductClass();

            orderId = buyProductObj.GetOrderId().ToString();

            lblOrderId.Text = " ORDER ID : " + orderId;
            ProductClass productClassObj = new ProductClass();
            DataSet ds = productClassObj.GetByProductId(productId);
            DataTable dt = ds.Tables[0];
            productBrand = dt.Rows[0][2].ToString();
            productRAM = dt.Rows[0][3].ToString();
            productProcessor = dt.Rows[0][4].ToString();
            productPrice = dt.Rows[0][7].ToString();
            var productDescription = productBrand + " " + productRAM + " " + productProcessor;
            //var price = productPrice;
            lblProductDescription.Text = productDescription.ToString();
            lblPrice.Text = productPrice;
            lblPriceAmt.Text = productPrice;
            lblAmountPayable.Text = productPrice;
            byte[] imgBytes = (byte[])dt.Rows[0][10];
            //byte[] imgData = (byte[]);
            btnImage.ImageUrl = Convert.ToBase64String(imgBytes);
            btnImage.ImageUrl = "~/ShowImage.ashx?id=" + imgBytes;
             }
                catch(NullReferenceException)
                {
                    Response.Redirect("Login.aspx");
                }
          catch (IndexOutOfRangeException)
          {
              Response.Redirect("Login.aspx");
          }
        }

        protected void btnRemove_Click(object sender, EventArgs e)
        {

            Session["ProductId"] = 0;
            Response.Redirect("Home.aspx");
        }

        protected void Button1_Click(object sender, EventArgs e)
        {

            // Value should take from session

            productId = Convert.ToInt32(Session["ProductId"].ToString());
            emailId = Session["EmailId"].ToString();
            string cardNo = txtCardNo.Text;
            string cardValidity = txtCardValidity.Text;
            string cardCVV = txtCardCVV.Text;
            string amount = productPrice;

            PaymentClass payObj = new PaymentClass();
            Boolean bankValidationResult = payObj.ValidateCredential(cardNo, cardValidity, cardCVV, amount);
            if (bankValidationResult == true)
            {
                BuyProductClass buyProductObj = new BuyProductClass();
                Boolean placeOrderResult = buyProductObj.PlaceOrderAfterPayment(Convert.ToInt32(orderId), cardNo, amount, emailId, productId);
                if (placeOrderResult == true)
                {
                    Response.Write("<script>alert('Your Order has been placed');</script>");
                    Response.Redirect("ViewSummary.aspx");
                }
            }
            else
                Response.Write("<script>alert('Your Transaction has Failed!!! ');</script>");


        }


        protected void txtContinue_Click(object sender, EventArgs e)
        {
            Response.Redirect("ViewSummary.aspx");
        }

    }
}