﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html.simpleparser;
using System.Data.SqlClient;
using System.Web.UI.HtmlControls;
using ShoppingCartDLL;
using System.Data;

namespace OnlineShoppingPortal.Pages
{
    public partial class ViewSummary : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //try
            //{
            //    string emailId = Session["EmailId"].ToString();
            //    ViewSummaryClass viewSummaryObj = new ViewSummaryClass();
            //    // GridView1.DataSource = viewSummaryObj.ViewSummary(emailId);
            //    DataSet ds = viewSummaryObj.ViewSummary(emailId);
            //    GridView1.DataSource = ds.Tables[0];
            //    GridView1.DataBind();
            //}
            //catch (NullReferenceException)
            //{
            //    Response.Redirect("Login.aspx");
            //}

            if (!this.IsPostBack)
            {
                try
                {
                    string emailId = Session["EmailId"].ToString();
                    ViewSummaryClass viewSummaryObj = new ViewSummaryClass();
                    // GridView1.DataSource = viewSummaryObj.ViewSummary(emailId);
                    DataSet ds = viewSummaryObj.ViewSummary(emailId);
                    GridView1.DataSource = ds.Tables[0];
                    GridView1.DataBind();
                }
                catch (NullReferenceException)
                {
                    Response.Redirect("Login.aspx");
                }

            }  

        }
      
        protected void btnCancelOrder_Click(object sender, EventArgs e)
        {
           
             int res=0;
             ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Your request has been recieved.')", true);
           Button btn = sender as Button;
           string temp = btn.CommandArgument;
           string[] temp1 = temp.Split(' ');
           int productId = int.Parse(temp1[0]);
           int orderId = int.Parse(temp1[1]);
         
           ViewSummaryClass viewSummaryObj = new ViewSummaryClass();
           viewSummaryObj.CancelOrder(productId, orderId);
           if (res==1)
           {
              
           }
         

           Response.Redirect("ViewSummary.aspx");

        }
        }

    

}