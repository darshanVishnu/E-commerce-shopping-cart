﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;
using ShoppingCartDLL;

namespace OnlineShoppingPortal.Pages
{
    public partial class Login1 : System.Web.UI.Page
    {
       
        protected void Page_Load(object sender, EventArgs e)
        {
           
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            Session["Emailid"]="null";
            LoginClass loginObj = new LoginClass();
           string usr= txtUserName.Text.ToString();
            string pwd=txtPwd.Text.ToString();
           int result = loginObj.LoginAuthentication(usr,pwd);
         
            if (result==1)
            {
               
                FormsAuthentication.RedirectFromLoginPage(txtUserName.Text,false);
                Session["EmailId"] = txtUserName.Text;
                string returnUrl = Request.QueryString["ReturnUrl"];
                if (returnUrl == null)
                {
                    Response.Redirect("Home.aspx");
                }
                else
                {
                     Response.Redirect(returnUrl);
                }
            
            }
            else
            {
               
                Response.Redirect("Login.aspx");
             
            }

           }
 
        }
    }
