﻿using ShoppingCartDLL;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OnlineShoppingPortal.Pages
{
    public partial class Register1 : System.Web.UI.Page
    {
        
        protected void Page_Load(object sender, EventArgs e)
        {
       
        }

        protected void Button1_Click(object sender, EventArgs e)
        { 
            Boolean result=false;
            CustomerClass customerObj= new CustomerClass();
            result=customerObj.ExistingCustomer(txtEmail.Text.Trim());
             
            if(result==true)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Email Id already Exist.Try with Different Email Id')", true);
            
            }
            else
            {

                string connectionString = ConfigurationManager.ConnectionStrings["OnlineShoppingPortalDBConnectionString"].ConnectionString;
                SqlConnection con = new SqlConnection(connectionString);
                SqlCommand cmd = new SqlCommand(connectionString, con);
       
            cmd.CommandText = "Prc_NewCustomer";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@emailId", SqlDbType.VarChar).Value = txtEmail.Text.Trim();
            cmd.Parameters.Add("@firstName", SqlDbType.VarChar).Value = txtFN.Text.Trim();
            cmd.Parameters.Add("@lastName", SqlDbType.VarChar).Value = txtLN.Text.Trim();
            cmd.Parameters.Add("@password", SqlDbType.VarChar).Value = txtPwd.Text.Trim();
            cmd.Parameters.Add("@mobileNo", SqlDbType.VarChar).Value = txtMob.Text.Trim();
            cmd.Parameters.Add("@gender", SqlDbType.VarChar).Value = rdbtnGender.Text.Trim();
            cmd.Parameters.Add("@doorNo", SqlDbType.VarChar).Value = txtDoor.Text.Trim();
            cmd.Parameters.Add("@streetName", SqlDbType.VarChar).Value = txtStreet.Text.Trim();
            cmd.Parameters.Add("@pincode", SqlDbType.Int).Value = txtPin.Text.Trim();
            cmd.Parameters.Add("@city", SqlDbType.VarChar).Value = txtCity.Text.Trim();
            cmd.Parameters.Add("@state", SqlDbType.VarChar).Value = txtState.Text.Trim();
            cmd.Parameters.Add("@country", SqlDbType.VarChar).Value = txtCountry.Text.Trim();
            cmd.Parameters.Add("@dob", SqlDbType.Date).Value = txtDOB.Text.Trim();
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            DisplayAlert("Registration Successful");
             }
           // Response.Redirect("Login.aspx");
            
        }
        protected virtual void DisplayAlert(string message)
        {
            ClientScript.RegisterStartupScript(this.GetType(), Guid.NewGuid().ToString(), string.Format("alert('{0}');window.location.href='Login.aspx'", message.Replace("'", @"\'").Replace("\n", "\\n").Replace("\r", "\\r")), true); 
        }

        //protected void Calendar1_SelectionChanged(object sender, EventArgs e)
        //{

        //    txtDOB.Text = Calendar1.SelectedDate.ToShortDateString();
        //}

        //protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        //{
        //    if (Calendar1.Visible == false)
        //    {


        //        Calendar1.Visible = true;
        //    }
        //    else
        //    {
        //        Calendar1.Visible = false;
        //    }
        //}
    }
}