﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OnlineShoppingPortal
{
    public partial class MasterTemplate : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!(Session["EmailId"] == null))
            {
                NotloggedInPH.Visible = false;
                LoggedInPH.Visible = true;
            }

        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            Response.Redirect("SearchItem.aspx?ProductBrand=" +
this.txtSearch.Text
);
        }

   
     
    }
}