﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShoppingCartDLL
{
    public class ProductClass
    {

        static SqlConnection scon = new SqlConnection("Data Source=INFVA07182;Initial Catalog=OnlineShoppingPortalDB;Persist Security Info=True;User ID=sa;Password=Newuser123");
        static SqlCommand scmd;


        public DataSet GetByProductId()
        {
            string q = "Prc_GetProductById";
            
            scmd  = new SqlCommand(q, scon);
            scmd.CommandType = CommandType.StoredProcedure;
            scmd.Parameters.AddWithValue("@productID", 10001);
            SqlDataAdapter adapter = new SqlDataAdapter();
            adapter.SelectCommand = scmd;
            DataSet ds = new DataSet();
            scon.Open();
            adapter.Fill(ds);
            
           
           
            scon.Close();

            return ds;
        }
 

    }
}
