﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace ShoppingCartDLL
{
   public class ViewSummaryClass
    {

        string connectionString = "Data Source=INFVA07182;Initial Catalog=OnlineShoppingPortalDB;Persist Security Info=True;User ID=sa;Password=Newuser123";


        public DataSet ViewSummary(string emailId)
        {
          
            string q = "Prc_ViewSummary";
            SqlConnection con = new SqlConnection(connectionString);
          
            SqlCommand cmd = new SqlCommand(q, con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@emailId", emailId);

            SqlDataAdapter adapter = new SqlDataAdapter();
            adapter.SelectCommand = cmd;
            DataSet ds = new DataSet();
            con.Open();
            adapter.Fill(ds);
            con.Close();

            return ds;
        }

        public Boolean CancelOrder(int productId, int orderId)
        {
            Boolean result= false;
            string q = "Prc_CancelOrder";
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand(q, con);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@productId", productId);
            cmd.Parameters.AddWithValue("@orderId", orderId);
            int row = cmd.ExecuteNonQuery();
            if(row>0)
            {
                result = true;
            }
            con.Close();
            return result;
        }
    }
}
