﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace ShoppingCartDLL
{
  public  class PaymentClass
    {

        static SqlConnection scon = new SqlConnection("Data Source=INFVA07182;Initial Catalog=OnlineShoppingPortalDB;Persist Security Info=True;User ID=sa;Password=Newuser123");
        static SqlCommand scmd;

        public Boolean ValidateCredential(string cardNo, string cardValidity, string cardCVV, string totalAmount)
        {

            int row = 0;
            Boolean result = false;

            string q = "Prc_BankValidation";

            scmd = new SqlCommand(q, scon);
            scmd.CommandType = CommandType.StoredProcedure;
            scmd.Parameters.AddWithValue("@cardNo", cardNo);
            scmd.Parameters.AddWithValue("@cardValidity", cardValidity);
            scmd.Parameters.AddWithValue("@cardCVV", cardCVV);
            scmd.Parameters.AddWithValue("@totalAmount", totalAmount);

            scon.Open();

            SqlDataReader dr = scmd.ExecuteReader();
            if (dr.Read())
            {
                result = true;
            }
            scon.Close();
            return result;

        }

    }
}
