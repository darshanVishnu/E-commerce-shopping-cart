﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace ShoppingCartDLL
{
    public class BuyProductClass
    {

        static SqlConnection scon = new SqlConnection("Data Source=INFVA07182;Initial Catalog=OnlineShoppingPortalDB;Persist Security Info=True;User ID=sa;Password=Newuser123");
        static SqlCommand scmd;


        public int GetOrderId()
        {

            //scmd.CommandType = CommandType.StoredProcedure;
            //scmd.CommandText = "Fun_GetOrderID";

            //SqlParameter returnValue = scmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
            //returnValue.Direction = ParameterDirection.ReturnValue;

            //scon.Open();
            //orderId= scmd.ExecuteScalar();

            //return returnValue.orderId;



            int orderId;
            string q = "Prc_GetOrderID";

            scmd = new SqlCommand(q, scon);
            scmd.CommandType = CommandType.StoredProcedure;
            scon.Open();
            orderId = Convert.ToInt32(scmd.ExecuteScalar());

            scon.Close();
            return orderId + 1;
        }

        public Boolean PlaceOrderAfterPayment(int orderId, string cardNo, string totalAmount, string emailId, int productId)
        {
            Boolean result = false;

            string q = "Prc_PlaceOrder";

            scmd = new SqlCommand(q, scon);
            scmd.CommandType = CommandType.StoredProcedure;
            scmd.Parameters.AddWithValue("@orderId", orderId);
            scmd.Parameters.AddWithValue("@cardNo", cardNo);
            scmd.Parameters.AddWithValue("@totalAmount", totalAmount);
            scmd.Parameters.AddWithValue("@emailId", emailId);
            scmd.Parameters.AddWithValue("@productId", productId);
            scon.Open();
            int row = scmd.ExecuteNonQuery();

            if (row > 0)
            {
                result = true;
            }
            scon.Close();
            return result;
        }
         
    }
}
