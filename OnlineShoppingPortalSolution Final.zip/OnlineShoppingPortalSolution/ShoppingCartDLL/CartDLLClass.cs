﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace ShoppingCartDLL
{
    public class CartDLLClass
    {
        public void AddToCart(string emailId, int productId)
        {
            SqlConnection scon = new SqlConnection("Data Source=INFVA07182;Initial Catalog=OnlineShoppingPortalDB;Persist Security Info=True;User ID=sa;Password=Newuser123");
            string q = "Prc_AddItemToCart";
            scon.Open();
            SqlCommand scmd = new SqlCommand(q, scon);
            scmd.CommandType = CommandType.StoredProcedure;
            scmd.Parameters.AddWithValue("@emailId", emailId);
            scmd.Parameters.AddWithValue("@productId", productId);
            scmd.ExecuteNonQuery();

     }

    }
}
