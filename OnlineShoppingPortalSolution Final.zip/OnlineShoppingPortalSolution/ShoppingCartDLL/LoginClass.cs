﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace ShoppingCartDLL
{
   public class LoginClass
    {
        public int LoginAuthentication(string emailId, string Password)
        {
    int result = 0;
            SqlConnection scon = new SqlConnection("Data Source=INFVA07182;Initial Catalog=OnlineShoppingPortalDB;Persist Security Info=True;User ID=sa;Password=Newuser123");
          //  string q = "select COUNT(*)FROM CustomerTable WHERE EmailId='" + emailId + "' and Password='" + Password + "'";
            string q = "Prc_LoginAuthentication";
            scon.Open();
            SqlCommand scmd = new SqlCommand(q, scon);
            scmd.CommandType = CommandType.StoredProcedure;
           scmd.Parameters.AddWithValue("@emailId", emailId);
           scmd.Parameters.AddWithValue("@password", Password);
            int OBJ = Convert.ToInt32(scmd.ExecuteScalar());
            if (OBJ ==1)
            {
                result = 1;

            }
           
            scon.Close();
            return result;


        }
    }
}
