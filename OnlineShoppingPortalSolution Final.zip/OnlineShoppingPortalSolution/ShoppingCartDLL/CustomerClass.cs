﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace ShoppingCartDLL
{
  public class CustomerClass
    {
        static SqlConnection scon = new SqlConnection("Data Source=INFVA07182;Initial Catalog=OnlineShoppingPortalDB;Persist Security Info=True;User ID=sa;Password=Newuser123");
        static SqlCommand scmd;


      //public Boolean NewCustomer(string emailId)
      //{
      //    string Q = "Data Source=INFVA07182;Initial Catalog=OnlineShoppingPortalDB;Persist Security Info=True;User ID=sa;Password=Newuser123";
      //    SqlConnection con = new SqlConnection(Q);
      //    SqlCommand cmd = new SqlCommand(Q, con);
      //    cmd.CommandText = "Prc_NewCustomer";
      //    cmd.CommandType = CommandType.StoredProcedure;
      //    cmd.Parameters.Add("@emailId", SqlDbType.VarChar).Value = txtEmail.Text.Trim();
      //    cmd.Parameters.Add("@firstName", SqlDbType.VarChar).Value = txtFN.Text.Trim();
      //    cmd.Parameters.Add("@lastName", SqlDbType.VarChar).Value = txtLN.Text.Trim();
      //    cmd.Parameters.Add("@password", SqlDbType.VarChar).Value = txtPwd.Text.Trim();
      //    cmd.Parameters.Add("@mobileNo", SqlDbType.VarChar).Value = txtMob.Text.Trim();
      //    cmd.Parameters.Add("@gender", SqlDbType.VarChar).Value = rdbtnGender.Text.Trim();
      //    cmd.Parameters.Add("@doorNo", SqlDbType.VarChar).Value = txtDoor.Text.Trim();
      //    cmd.Parameters.Add("@streetName", SqlDbType.VarChar).Value = txtStreet.Text.Trim();
      //    cmd.Parameters.Add("@pincode", SqlDbType.Int).Value = txtPin.Text.Trim();
      //    cmd.Parameters.Add("@city", SqlDbType.VarChar).Value = txtCity.Text.Trim();
      //    cmd.Parameters.Add("@state", SqlDbType.VarChar).Value = txtState.Text.Trim();
      //    cmd.Parameters.Add("@country", SqlDbType.VarChar).Value = txtCountry.Text.Trim();
      //    cmd.Parameters.Add("@dob", SqlDbType.Date).Value = txtDOB.Text.Trim();
      //    con.Open();
      //    cmd.ExecuteNonQuery();
      //    con.Close();

      //}
      public Boolean ExistingCustomer(string emailId)
      {
          Boolean result = false;

            string q = "Prc_CheckCustomerExist";

            scmd = new SqlCommand(q, scon);
            scmd.CommandType = CommandType.StoredProcedure;
            scmd.Parameters.AddWithValue("@emailId", emailId);
           
            scon.Open();

            SqlDataReader dr = scmd.ExecuteReader();
            if (dr.Read())
            {
                result = true;
            }
            scon.Close();
            return result;

        
      }
    }
}
