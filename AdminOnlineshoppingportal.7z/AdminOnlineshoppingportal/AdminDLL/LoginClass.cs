﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdminDLL
{
   public class LoginClass

         
    {

       public int LoginAuthentication(string emailId, string Password)
       {
           int result = 0;
           SqlConnection scon = new SqlConnection("Data Source=DESKTOP-44I1V3G;Initial Catalog=OnlineShoppingPortalDB;Persist Security Info=True;User ID=sa;Password=9972517901");
           //string q = "select COUNT(*)FROM AdminTable WHERE AdminName='" + emailId + "' and Password='" + Password + "'";
           string q = "Prc_LoginAdmin";
           scon.Open();
           SqlCommand scmd = new SqlCommand(q, scon);
         //  int c = scmd.;

          scmd.CommandType = CommandType.StoredProcedure;
        scmd.Parameters.AddWithValue("@adminName",emailId);
         scmd.Parameters.AddWithValue("@password",Password);
           int obj = Convert.ToInt32(scmd.ExecuteScalar());
           if (obj == 1)
           {
               result = 1;

           }
           scon.Close();
           return result;


       }
    }
}
