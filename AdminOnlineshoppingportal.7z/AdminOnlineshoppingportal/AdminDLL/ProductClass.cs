﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace AdminDLL
{
    public class ProductClass
    {
        static SqlConnection scon = new SqlConnection("Data Source=DESKTOP-44I1V3G;Initial Catalog=OnlineShoppingPortalDB;Persist Security Info=True;User ID=sa;Password=9972517901");
         SqlCommand scmd;


        public Boolean AddProduct(string name,string brand, string pRAM, string pProcessor, string productGraphic, string pOS,int price, byte[] image)
        {
            
            Boolean result = false;
          
                string q = "Prc_InsertNewProduct";
                scon.Open();

                scmd = new SqlCommand(q, scon);
                scmd.CommandType = CommandType.StoredProcedure;

                scmd.Parameters.AddWithValue("@productName", name);
                scmd.Parameters.AddWithValue("@productBrand", brand);
                scmd.Parameters.AddWithValue("@productRAM", pRAM);
                scmd.Parameters.AddWithValue("@productOS", pOS);
                scmd.Parameters.AddWithValue("@productProcessor", pProcessor);
                scmd.Parameters.AddWithValue("@productGraphic", productGraphic);
                scmd.Parameters.AddWithValue("@productPrice", price);
                scmd.Parameters.AddWithValue("@productImage", image);

            string description = name+"s"+brand+"s"+pRAM+ pProcessor+productGraphic+pOS+price;

           scmd.Parameters.AddWithValue("@productdescription", description);
             

                long row = scmd.ExecuteNonQuery();
                if (row > 0)
                {
                    result = true;
                
                
                }
            
          
            
                scon.Close();
              

                  return result;

        }
    }
}
