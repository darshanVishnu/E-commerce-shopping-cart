﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AdminOnlineshoppingportal.Pages
{
    public partial class Home : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!Page.IsPostBack)
            {
                //    string connectionString = ConfigurationManager.ConnectionStrings["OnlineShoppingPortalDBConnectionString"].ConnectionString;
                string q = "Data Source=DESKTOP-44I1V3G;Initial Catalog=OnlineShoppingPortalDB;Persist Security Info=True;User ID=sa;Password=9972517901";
                DataTable dt = new DataTable();
                SqlConnection conn = new SqlConnection(q);
                using (conn)
                {
                    SqlDataAdapter ad = new SqlDataAdapter("SELECT * FROM ProductTable", conn);
                    ad.Fill(dt);
                }
                DataList1.DataSource = dt;
                DataList1.DataBind();
            }
        }
    }
}