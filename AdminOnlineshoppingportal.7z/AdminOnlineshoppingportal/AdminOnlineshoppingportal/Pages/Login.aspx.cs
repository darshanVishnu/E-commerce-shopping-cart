﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using AdminDLL;

namespace AdminOnlineshoppingportal.Pages
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
          

            Session["Emailid"] = "null";
            LoginClass loginObj = new LoginClass();
            string usr = txtAdminName.Text.ToString();
            string pwd = txtPwd.Text.ToString();
            int result = loginObj.LoginAuthentication(usr, pwd);

            if (result==1 )
            {

                FormsAuthentication.RedirectFromLoginPage(txtAdminName.Text,false);
                string returnUrl=Request.QueryString["ReturnUrl"];
                Session["EmailId"] = txtAdminName.Text;

               // if(returnUrl==null)
              //  {
                 //   Response.Redirect("Home.aspx");
                                //    }
              //  else{
              //  Response.Redirect(returnUrl);
              //  }
            Response.Redirect("AddItem.aspx");

            }
            else
            {

                Response.Redirect("Login.aspx");
            }

          
           
        }
    
}}
