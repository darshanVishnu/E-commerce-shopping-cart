﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AdminOnlineshoppingportal.Pages
{
    public partial class AddQuantity : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {

                string connectionString = "Data Source=INFVA07182;Initial Catalog=OnlineShoppingPortalDB;Persist Security Info=True;User ID=sa;Password=Newuser123";
                string q = "Select * from ProductTable";
                SqlConnection con = new SqlConnection(connectionString);
                con.Open();
                SqlCommand cmd = new SqlCommand(q, con);
              //  cmd.CommandType = CommandType.StoredProcedure;
                //cmd.Parameters.AddWithValue("@emailId", Session["EmailId"].ToString());
                SqlDataReader dr = cmd.ExecuteReader();
                GridView1.DataSource = dr;
                GridView1.DataBind();
             
                con.Close();

            }
        }

    public void btnUpdate_Click(object sender,EventArgs  e)
        {
            Button btn = sender as Button;
            int cds = Convert.ToInt32(btn.CommandArgument);
            Session["ProductId"] = cds;
           // int id = int.Parse(GridView1.DataKeys[e.RowIndex].Value.ToString());
          //  string q = "Prc_AdminDeleteproduct";
          //  SqlConnection con = new SqlConnection("Data Source=INFVA07182;Initial Catalog=OnlineShoppingPortalDB;Persist Security Info=True;User ID=sa;Password=Newuser123");
        //    con.Open();
         //   SqlCommand cmd=new SqlCommand(q,con);
          //  cmd.CommandType = CommandType.StoredProcedure;
         //   cmd.Parameters.AddWithValue("@productId",cds);
         //   cmd.ExecuteNonQuery();
        
            
      
           
           
          //  con.Close();
            Response.Redirect("Updateitem.aspx");
        }  
    }
}