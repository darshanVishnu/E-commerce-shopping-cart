﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AdminDLL;

namespace AdminOnlineshoppingportal.Pages
{
    public partial class AddItem : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void txtProductPrice_TextChanged(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            string productName = txtName.Text;
            string productBrand = txtBrand.Text;
            string productRAM = txtRAM.Text;
            string productOS = txtProductOSVersion.Text;
            string productProcessor = txtProcessor.Text;
            string productGraphic = txtGraphics.Text;
            int price = Convert.ToInt32(txtProductPrice.Text);


            int length = fuProductImage.PostedFile.ContentLength;
            byte[] pic = new byte[length];


            fuProductImage.PostedFile.InputStream.Read(pic, 0, length);



            Response.Write("<script>alert('Testing 2');</script>");

            ProductClass productObj = new ProductClass();
            Boolean result =

productObj.AddProduct(productName, productBrand, productRAM, productOS, productProcessor, productGraphic, price, pic);
            Response.Write("<script>alert('Testing 3');</script>");
            if (result == true)
            {
                Response.Write("<script>alert('Product has been inserted successfully');</script>");
            }
            else
                Response.Write("<script>alert('Sorry !!!  Error in inserting product details');</script>");

            Response.Write("<script>alert('Testing 1');</script>");

           
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}