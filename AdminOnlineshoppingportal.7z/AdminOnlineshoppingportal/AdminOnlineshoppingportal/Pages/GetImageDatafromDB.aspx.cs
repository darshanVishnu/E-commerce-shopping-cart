﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AdminOnlineshoppingportal
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string sProductID = Request.QueryString["id"];
                string q = "Data Source=DESKTOP-44I1V3G;Initial Catalog=OnlineShoppingPortalDB;Persist Security Info=True;User ID=sa;Password=9972517901";
               // string constr = ConfigurationManager.ConnectionStrings["OnlineShoppingPortalDBConnectionString"].ConnectionString;
                string sQuery = "SELECT productimage FROM producttable WHERE productId = @productid";

                SqlConnection con = new SqlConnection(q);
                SqlCommand cmd = new SqlCommand(sQuery, con);

                cmd.Parameters.Add("@productid", SqlDbType.Int).Value = Int32.Parse(sProductID);

                using (con)
                {
                    con.Open();
                    SqlDataReader DR = cmd.ExecuteReader();

                    if (DR.Read())
                    {
                        byte[] imgData = (byte[])DR["productimage"];
                        Response.BinaryWrite(imgData);
                    }
                }
            }
        }


    }
}
