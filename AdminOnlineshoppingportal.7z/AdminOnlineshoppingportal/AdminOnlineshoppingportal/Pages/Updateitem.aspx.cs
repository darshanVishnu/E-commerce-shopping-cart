﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AdminOnlineshoppingportal.Pages
{
    public partial class Updateitem : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string connectionString = "Data Source=INFVA07182;Initial Catalog=OnlineShoppingPortalDB;Persist Security Info=True;User ID=sa;Password=Newuser123";
            string q = "Select * from ProductTable where ProductId ="+Session["ProductId"]+"";
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand(q, con);
          
            SqlDataReader dr = cmd.ExecuteReader();
          
        while (dr.Read())
				{
					// get the results of each column
					txtLaptop.Text = (string)dr["ProductLaptop"];
					txtBrand.Text = (string)dr["Productbrand"];
              //      txtGraphics = (string)dr[""];
               //     txtProcessor = (string)dr[""];

				
				}
        con.Close();
        
        }

        protected void btnUpadte_Click(object sender, EventArgs e)
        {
            string productName = txtLaptop.Text.Trim().ToLower();
            string productBrand = txtBrand.Text;
            string productRAM = txtRAM.Text;
            string productOS = txtProductOSVersion.Text;
            string productProcessor = txtProcessor.Text;
            string productGraphic = txtGraphics.Text;
            int price = Convert.ToInt32(txtProductPrice.Text);


            int length = fuProductImage.PostedFile.ContentLength;
            byte[] pic = new byte[length];


            fuProductImage.PostedFile.InputStream.Read(pic, 0, length);



            Response.Write("<script>alert('Testing 2');</script>");
        }
    }
}